// t_ui.js — Phase 11 UI SYSTEM (minimal auto-hiding HUD, health pips,
// persisted settings, save/load panel). Run AFTER the harness + game source.
// Uses the DOM/localStorage stubs from harness.js.
(function(){
  const fails=[];
  function chk(c,m){ if(!c) fails.push(m); }

  // ---- boot + start a game so G.player/G.scene exist ----
  try{ boot(); }catch(e){ fails.push('boot() threw: '+e.message); }
  try{ startGame(true); }catch(e){ fails.push('startGame threw: '+e.message); }

  // ============================ 1. surface ============================
  chk(typeof UI==='object'&&UI!==null,'UI system object exists');
  ['load','save','reset','apply','applyVolume','init','healthPips',
   'openSettings','closeSettings','renderSettings',
   'openSaveLoad','closeSaveLoad','saveInfo','renderSaveLoad','doSave','doLoad','update'
  ].forEach(f=>chk(typeof UI[f]==='function','UI.'+f+'() is a function'));
  ['sens','volume','subtitles','grain','quality','camDist','hudAuto']
    .forEach(k=>chk(k in UI.SET,'setting "'+k+'" exists in UI.SET'));
  chk(typeof SETKEY==='string'&&SETKEY.length>0,'SETKEY persistence key defined');

  // ============================ 2. settings persistence ============================
  UI.SET.sens=2.0; UI.SET.volume=0.4; UI.save();
  const raw=localStorage.getItem(SETKEY);
  chk(!!raw,'settings are written to localStorage');
  chk(raw&&raw.indexOf('"sens":2')>=0,'persisted JSON contains the changed value');
  UI.SET.sens=1.0; UI.SET.volume=0.85; UI.load();
  chk(Math.abs(UI.SET.sens-2.0)<1e-6,'load() restores sensitivity from storage');
  chk(Math.abs(UI.SET.volume-0.4)<1e-6,'load() restores volume from storage');
  UI.reset();
  chk(Math.abs(UI.SET.sens-UI.DEF.sens)<1e-6,'reset() restores default sensitivity');
  chk(UI.SET.subtitles===UI.DEF.subtitles,'reset() restores default subtitles');

  // ============================ 3. apply() pushes to engine ============================
  UI.SET.sens=1.8; UI.SET.quality=1; UI.SET.camDist=3.3; UI.SET.volume=0.5;
  UI.apply();
  chk(Math.abs(IN.sens-1.8)<1e-6,'apply() pushes sensitivity into IN.sens');
  chk(E3.quality===1,'apply() pushes render quality into E3.quality');
  chk(Math.abs(E3.camDist-3.3)<1e-6,'apply() pushes camera distance into E3.camDist');
  // clamping
  UI.SET.sens=99; UI.apply();
  chk(IN.sens<=2.5+1e-6,'apply() clamps sensitivity to the max');
  UI.SET.sens=1.0; UI.apply();

  // ============================ 4. subtitle gate ============================
  UI.SET.subtitles=true; G.subtitleT=0;
  subtitle('','تجربة الترجمة');
  chk(G.subtitleT>0,'subtitles play when enabled (subtitleT set)');
  chk($('sub').style.opacity==1,'subtitle element is shown when enabled');
  UI.SET.subtitles=false; G.subtitleT=0;
  subtitle('','تجربة الترجمة');
  chk(G.subtitleT===0,'subtitles are suppressed when disabled');
  chk($('sub').style.opacity==0,'subtitle element stays hidden when disabled');
  UI.SET.subtitles=true;

  // ============================ 5. health pips + vitals relevance ============================
  // healthPips must not throw even with the stub (no children)
  let hpOk=true; try{ UI.healthPips(2); UI.healthPips(0); }catch(e){ hpOk=false; }
  chk(hpOk,'UI.healthPips() runs without throwing');
  enterScene('slice_bld',SCENES.slice_bld.spawn,{silent:true});
  const P=G.player;
  G.showVitals=0; P.hp=3; P.sta=100; P.bat=100; P.rad=0; P.injured=0;
  updatePlayer(1/60);
  chk(!$('vitals').classList.contains('hot'),'vitals stay dim when healthy & safe (minimal HUD)');
  G.showVitals=0; P.hp=1; P.injured=0; P.sta=100; P.bat=100; P.rad=0;
  updatePlayer(1/60);
  chk($('vitals').classList.contains('hot'),'vitals (incl. health) surface when hurt');
  P.hp=3; P.injured=0;

  // ============================ 6. HUD auto-hide ============================
  // idle + safe -> HUD fades out
  UI.SET.hudAuto=true; UI.hudA=1; UI.actT=0; UI._lastObj=G.objective;
  P.moving=false; P.sprint=false; P.injured=0; P.dmgFlash=0;
  G.threat=0; G.subtitleT=0; curInt=null; G.started=true; G.over=false;
  IN.keys={}; IN.joy={x:0,y:0}; IN.lookX=0; IN.lookY=0;
  DLG.open=false; DOC.open=false; NB.open=false; INVUI.open=false; CODE.open=false; PZUI.open=false;
  UI.setOpen=false; UI.slOpen=false;
  for(let i=0;i<240;i++)UI.update(1/60); // ~4s idle
  chk(UI.hudA<0.12,'HUD fades out when the player is idle and safe');
  chk(parseFloat($('hud').style.opacity)<0.12,'#hud opacity follows the fade');
  // movement -> HUD fades back in
  P.moving=true;
  for(let i=0;i<40;i++)UI.update(1/60);
  chk(UI.hudA>0.8,'HUD fades back in on movement');
  P.moving=false;
  // threat keeps it visible
  UI.hudA=0; UI.actT=0; G.threat=0.5;
  for(let i=0;i<10;i++)UI.update(1/60);
  chk(UI.actT>0,'a threat resets the auto-hide timer');
  G.threat=0;
  // an interaction prompt keeps it visible
  UI.hudA=0; UI.actT=0; curInt={type:'door'};
  UI.update(1/60);
  chk(UI.actT>0,'an interaction prompt keeps the HUD awake');
  curInt=null;
  // auto-hide OFF -> always visible
  UI.SET.hudAuto=false; UI.hudA=0; UI.actT=0;
  for(let i=0;i<240;i++)UI.update(1/60);
  chk(UI.hudA>0.9,'with auto-hide disabled the HUD stays visible');
  chk(parseFloat($('hud').style.opacity)>0.9,'#hud opacity stays high when auto-hide is off');
  UI.SET.hudAuto=true;

  // ============================ 7. settings panel open/close ============================
  UI.openSettings('menu');
  chk(UI.setOpen===true,'openSettings() sets the modal flag');
  chk(!$('settings').classList.contains('hide'),'the settings panel is shown');
  chk($('menu').classList.contains('hide'),'the menu is hidden behind settings');
  UI.renderSettings();
  chk($('setBody').children.length>=6,'renderSettings() builds the setting rows');
  UI.closeSettings();
  chk($('settings').classList.contains('hide')&&!UI.setOpen,'closeSettings() hides the panel');
  chk(!$('menu').classList.contains('hide'),'...and returns to the menu (from=menu)');
  UI.openSettings('pause');
  UI.closeSettings();
  chk(!$('pause').classList.contains('hide'),'...and returns to pause (from=pause)');

  // ============================ 8. save/load panel ============================
  UI.openSaveLoad('pause');
  chk(UI.slOpen===true,'openSaveLoad() sets the modal flag');
  chk(!$('saveload').classList.contains('hide'),'the save/load panel is shown');
  chk($('pause').classList.contains('hide'),'the pause menu is hidden behind it');
  G.started=true; G.over=false; G.paused=true;
  const saved=UI.doSave();
  chk(saved===true,'doSave() saves while a game is running');
  const info=UI.saveInfo();
  chk(info&&info.scene,'saveInfo() reads saved-game metadata');
  chk(info&&typeof info.hp==='number','saveInfo() exposes health');
  UI.closeSaveLoad();
  chk($('saveload').classList.contains('hide')&&!UI.slOpen,'closeSaveLoad() hides the panel');
  let dlOk=true; try{ UI.doLoad(); }catch(e){ dlOk=false; }
  chk(dlOk,'doLoad() runs without throwing');
  // saving is refused when the game is over
  G.over=true; const refused=UI.doSave(); G.over=false;
  chk(refused===false,'doSave() refuses when the game is over');

  // ============================ 9. boot wiring ============================
  chk(typeof $('btnSettings').onclick==='function','pause Settings button is wired');
  chk(typeof $('btnLoad').onclick==='function','pause Load button is wired');
  chk(typeof $('btnSetM').onclick==='function','menu Settings button is wired');
  chk(typeof $('btnSetClose').onclick==='function','settings Close button is wired');
  chk(typeof $('btnSetReset').onclick==='function','settings Reset button is wired');
  chk(typeof $('btnSlSave').onclick==='function','save/load Save button is wired');
  chk(typeof $('btnSlLoad').onclick==='function','save/load Load button is wired');
  chk(typeof $('btnSlClose').onclick==='function','save/load Close button is wired');

  // ============================ 10. keydown guards (Escape closes panels) ============================
  UI.openSettings('pause');
  __fireWin('keydown',{code:'Escape',key:'Escape'});
  chk(!UI.setOpen&&$('settings').classList.contains('hide'),'Escape closes the settings panel');
  UI.openSaveLoad('pause');
  __fireWin('keydown',{code:'Escape',key:'Escape'});
  chk(!UI.slOpen&&$('saveload').classList.contains('hide'),'Escape closes the save/load panel');

  // ============================ report ============================
  const total=fails.length;
  if(total){ console.log('FAIL x'+total); fails.forEach(f=>console.log('  - '+f)); }
  else console.log('UI SYSTEM SUITE OK');
  console.log('checks_failed='+total);
  if(typeof process!=='undefined')process.exit(total?1:0);
})();
