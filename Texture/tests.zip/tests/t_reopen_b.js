// t_reopen_b.js — "reopen the game" process: fresh JS context, nothing in
// memory. Seed localStorage from the file the "closed" game left behind,
// boot, press Continue, and verify the whole world came back.
(function(){
  const fails=[];
  function chk(c,m){ if(!c) fails.push(m); }
  const fs=require('fs');

  /* the store was seeded BEFORE the game source parsed (like a real
     browser: localStorage exists before the page's JS runs) */
  const st=JSON.parse(fs.readFileSync('/tmp/ch_reopen_store.json','utf8'));
  for(const k in st)chk(localStorage.getItem(k)===st[k],'persisted key survived the reopen: '+k);
  const ex=JSON.parse(fs.readFileSync('/tmp/ch_reopen_expect.json','utf8'));

  try{ boot(); }catch(e){ fails.push('boot() threw after reopen: '+e.message); }
  chk(hasSave()===true,'a save exists after reopening the game');
  chk($('btnCont')&&$('btnCont').style.opacity!==0.35,'the Continue button is enabled');

  startGame(false);                           // "متابعة" (Continue)
  chk(G.started===true,'Continue starts the loaded game');
  chk(G.sceneId===ex.sceneId,'the saved scene was re-entered ('+G.sceneId+')');
  const P=G.player;
  chk(Math.abs(P.x-ex.px)<1e-9&&Math.abs(P.y-ex.py)<1e-9,'player position restored');
  chk(P.hp===ex.hp&&Math.abs(P.rad-ex.rad)<1e-9,'health + radiation restored');
  chk(Math.abs(P.face-ex.face)<1e-9&&Math.abs(P.modelYaw-ex.modelYaw)<1e-9,'facing restored');
  chk(P.injured===ex.injured&&Math.abs(P.sta-ex.sta)<1e-9&&Math.abs(P.bat-ex.bat)<1e-9,'injury + stamina + battery restored');
  chk(G.items.medkit===ex.medkit&&!!G.items.keycard===ex.keycard,'inventory restored');
  chk(G.story&&G.story.chapter===ex.chapter&&G.story.obj===ex.obj,'story chapter + objective restored');
  chk(!!G.story.doneObj.ch1_reach_city===ex.doneReach,'completed objective restored');
  chk(PZ.state('sym').done[0]===ex.pzStep,'puzzle progress restored');
  chk(!!G.evt.done.ch1_city_echo===ex.evtDone,'world-event state restored');
  const door=SCENES.outdoor.doors.find(d=>d.id===ex.doorId);
  const int=(SCENES.outdoor.ints||[]).find(i=>i.id===ex.intId);
  chk(door&&door.open===true,'the opened door is still open');
  chk(int&&int.used===true,'the used interactable is still used');
  chk(Math.abs(UI.SET.sens-ex.sens)<1e-6,'settings restored');

  const total=fails.length;
  if(total){ console.log('FAIL x'+total); fails.forEach(f=>console.log('  - '+f)); }
  else console.log('REOPEN (CLOSE + REOPEN) SUITE OK');
  console.log('checks_failed='+total);
  process.exit(total?1:0);
})();
