// t_reopen_a.js — "close the game" process: boot, play, save, dump the
// whole localStorage store to disk (as a browser would keep it), exit.
(function(){
  const fails=[];
  function chk(c,m){ if(!c) fails.push(m); }
  const fs=require('fs');

  try{ boot(); }catch(e){ fails.push('boot() threw: '+e.message); }
  localStorage.clear();
  startGame(true);

  /* --- play the game a bit: move, get hurt, collect, progress --- */
  const P=G.player;
  P.x=12.5;P.y=8.25;P.hp=2;P.rad=1.4;P.face=1.9;P.modelYaw=1.1;P.injured=5;P.sta=55;P.bat=0.6;
  G.items.medkit=2;G.items.keycard=true;
  G.story=defaultStory();STORY.start('ch1');
  G.story.obj='ch1_trace';G.story.doneObj.ch1_reach_city=true;G.story.vars.k=3;
  PZ.state('sym').done.push('s1');
  G.evt.done.ch1_city_echo=true;
  const door=SCENES.outdoor.doors.find(d=>d.id)||SCENES.outdoor.doors[0];
  const int=(SCENES.outdoor.ints||[]).find(i=>i.id)||(SCENES.outdoor.ints||[])[0];
  door.open=true;int.used=true;
  UI.SET.sens=2.1;UI.save();

  saveGame(false,'2');
  chk(readSlot('2')!==null,'manual save written before "closing" the game');
  chk(listSaves().indexOf('2')>=0,'slot 2 is listed');

  /* --- "close the game": persist only what a browser keeps --- */
  fs.writeFileSync('/tmp/ch_reopen_store.json',JSON.stringify(__store));
  fs.writeFileSync('/tmp/ch_reopen_expect.json',JSON.stringify({
    sceneId:G.sceneId,px:P.x,py:P.y,hp:P.hp,rad:P.rad,face:P.face,modelYaw:P.modelYaw,
    injured:P.injured,sta:P.sta,bat:P.bat,
    medkit:G.items.medkit,keycard:!!G.items.keycard,
    chapter:G.story.chapter,obj:G.story.obj,doneReach:!!G.story.doneObj.ch1_reach_city,
    pzStep:PZ.state('sym').done[0],evtDone:!!G.evt.done.ch1_city_echo,
    doorId:door.id,intId:int.id,sens:UI.SET.sens
  }));
  console.log(fails.length? 'REOPEN_A FAIL x'+fails.length : 'REOPEN_A_OK (game "closed")');
  process.exit(fails.length?1:0);
})();
