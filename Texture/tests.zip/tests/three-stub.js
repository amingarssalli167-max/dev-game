/* Minimal THREE stub — exercises the 3D code paths (geometry, scene graph,
   per-frame updates) in Node without WebGL. */
let _id=1;
class V3{constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;}
  set(x,y,z){this.x=x;this.y=y;this.z=z;return this;}
  copy(v){this.x=v.x;this.y=v.y;this.z=v.z;return this;}
  length(){return Math.hypot(this.x,this.y,this.z);}
  distanceTo(v){return Math.hypot(this.x-v.x,this.y-v.y,this.z-v.z);}}
class Col{constructor(c){this.set(c);}
  set(c){this.v=c;
    if(Array.isArray(c)){this.r=c[0];this.g=c[1];this.b=c[2];}
    else{this.r=((c>>16)&255)/255;this.g=((c>>8)&255)/255;this.b=(c&255)/255;}
    return this;}
  setHex(h){return this.set(h);}
  setRGB(r,g,b){this.v=[r,g,b];this.r=r;this.g=g;this.b=b;return this;}
  getHex(){return (Math.round(this.r*255)<<16|Math.round(this.g*255)<<8|Math.round(this.b*255))>>>0;}}
class Obj3D{
  constructor(){this.id=_id++;this.children=[];this.position=new V3();this.rotation={x:0,y:0,z:0,order:'XYZ'};
    this.scale={x:1,y:1,z:1,setScalar(v){this.x=this.y=this.z=v;return this;}};
    this.userData={};this.visible=true;this.parent=null;this.matrixAutoUpdate=true;}
  add(o){if(o){this.children.push(o);o.parent=this;}return this;}
  remove(o){const i=this.children.indexOf(o);if(i>=0)this.children.splice(i,1);return this;}
  traverse(f){f(this);this.children.forEach(c=>c.traverse&&c.traverse(f));}
  lookAt(){return this;}
  updateMatrix(){}
  updateProjectionMatrix(){}
}
class Scene extends Obj3D{constructor(){super();this.fog=null;this.background=null;}}
class Group extends Obj3D{}
class Camera extends Obj3D{constructor(){super();this.fov=70;this.aspect=1;this.near=0.1;this.far=100;}}
class PerspectiveCamera extends Camera{constructor(f,a,n,fa){super();this.fov=f;this.aspect=a;this.near=n;this.far=fa;}}
class Light extends Obj3D{constructor(c,i,d){super();this.color=new Col(c);this.intensity=i==null?1:i;
  this.distance=d||0;this.castShadow=false;this.shadow={mapSize:{width:512,height:512},camera:{},bias:0,map:null};}
  set target(o){this._t=o;} get target(){return this._t;}}
class PointLight extends Light{}
class DirectionalLight extends Light{}
class SpotLight extends Light{constructor(c,i,d,a,p,dec){super(c,i,d);this.angle=a;this.penumbra=p;this.decay=dec;}}
class HemisphereLight extends Light{constructor(sk,gr,i){super(sk,i,0);this.groundColor=new Col(gr);}}
class AmbientLight extends Light{}
class FogExp2{constructor(c,d){this.color=new Col(c);this.density=d;}}
class BufferGeometry{
  constructor(){this.attributes={};this.index=null;this.groups=[];}
  setAttribute(n,a){this.attributes[n]=a;return this;}
  setIndex(i){this.index=i;return this;}
  addGroup(st,c,m){this.groups.push({start:st,count:c,materialIndex:m});return this;}
  computeBoundingSphere(){this.boundingSphere={radius:10,center:new V3()};}
  dispose(){this._disposed=true;}
}
class Float32BufferAttribute{constructor(arr,item){this.array=Float32Array.from(arr);this.itemSize=item;this.count=arr.length/item;}}
class BoxGeometry extends BufferGeometry{constructor(w=1,h=1,d=1){super();this.p={w,h,d};}}
class PlaneGeometry extends BufferGeometry{constructor(w=1,h=1){super();this.p={w,h};}}
class CylinderGeometry extends BufferGeometry{constructor(rt=1,rb=1,h=1,s=8){super();this.p={rt,rb,h,s};}}
class TorusGeometry extends BufferGeometry{constructor(r=1,t=.1,a=8,b=8){super();this.p={r,t};}}
class CapsuleGeometry extends BufferGeometry{constructor(r=1,l=1,a=4,b=8){super();this.p={r,l};}}
class Material{constructor(o={}){Object.assign(this,o);this.id=_id++;this.userData={};
  if(this.color===undefined)this.color=new Col(0xffffff);}
  dispose(){this._disposed=true;}}
class MeshLambertMaterial extends Material{}
class MeshBasicMaterial extends Material{}
class Mesh extends Obj3D{constructor(g,m){super();this.geometry=g;this.material=m;
  this.castShadow=false;this.receiveShadow=false;}}
class Texture{constructor(){this.offset={x:0,y:0};this.wrapS=0;this.wrapT=0;this.anisotropy=1;this.id=_id++;}
  dispose(){this._disposed=true;}}
class CanvasTexture extends Texture{constructor(c){super();this.image=c;}}
class WebGLRenderer{
  constructor(o={}){this.domElement=(o&&o.canvas)||{style:{}};this.shadowMap={enabled:false,type:0};
    this.info={render:{calls:0,triangles:0}};this.renderCount=0;this.opts=o||{};}
  setPixelRatio(v){this.pr=v;} setSize(w,h,u){this.w=w;this.h=h;this.us=u;}
  render(sc,cam){this.renderCount++;this.lastScene=sc;this.lastCam=cam;}
  dispose(){}
}
class Raycaster{constructor(){this.ray={origin:new V3(),direction:new V3()};}
  set(){} intersectObjects(){return [];}}
class Euler{constructor(){this.x=this.y=this.z=0;}}
const THREE={
  REVISION:160,
  Scene,Group,Mesh,Object3D:Obj3D,PerspectiveCamera,Camera,
  WebGLRenderer,Raycaster,Euler,
  BoxGeometry,PlaneGeometry,CylinderGeometry,TorusGeometry,CapsuleGeometry,
  BufferGeometry,Float32BufferAttribute,
  MeshLambertMaterial,MeshBasicMaterial,
  PointLight,DirectionalLight,SpotLight,HemisphereLight,AmbientLight,
  FogExp2,CanvasTexture,Texture,
  Vector3:V3,Color:Col,
  SRGBColorSpace:'srgb',
  RepeatWrapping:1000,ClampToEdgeWrapping:1001,
  DoubleSide:2,FrontSide:0,BackSide:1,
  AdditiveBlending:2,NormalBlending:1,
  PCFSoftShadowMap:2,ACESFilmicToneMapping:4,
  MathUtils:{clamp:(v,a,b)=>Math.max(a,Math.min(b,v)),lerp:(a,b,t)=>a+(b-a)*t},
};
global.THREE=THREE;
