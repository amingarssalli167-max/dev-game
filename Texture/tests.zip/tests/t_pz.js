/* ---- Phase 6: Puzzle Framework ---- */
let fails=0;
const ok=m=>console.log('  ok  '+m);
const bad=m=>{console.log('FAIL  '+m);fails++;};
const chk=(c,m)=>c?ok(m):bad(m);

boot();
startGame(true);
function closeAll(){DLG.open=false;DOC.open=false;CODE.open=false;NB.open=false;INVUI.open=false;PZUI.open=false;G.paused=false;}
function face(c,ox,oy){
  G.player.x=c.x+(ox||0);G.player.y=c.y+(oy==null?0.6:oy);
  IN.aim=Math.atan2(c.y-G.player.y,c.x-G.player.x);
  IN.movedByMouse=true;G.player.hidden=false;updateHint();return curInt;
}
const SB=()=>SCENES.slice_bld;
const node=sid=>SB().ints.find(i=>i.step===sid&&i.puzzle==='pz_lockbox');
const body=()=>$('pzBody');
const kids=()=>body().children.slice();
const byClass=c=>kids().find(x=>x.className===c);
const byText=t=>kids().find(x=>(x.innerHTML||'').indexOf(t)>=0);
function reset(){G.pz={};G.flags={};G.items={};G.echo=0;closeAll();}

/* ============ 0. framework surface ============ */
chk(typeof PUZZLES==='object','PUZZLES registry present');
chk(typeof defPuzzle==='function','defPuzzle() present');
chk(typeof PZUI==='object','PZUI state present');
['def','state','step','stepSolved','solved','requireMet','nodeState','node','open','close','check','submit','advance','reward']
  .forEach(fn=>chk(typeof PZ[fn]==='function','PZ.'+fn+'()'));

/* ============ 1. demo puzzle is registered with a multi-step chain ============ */
const lp=PZ.def('pz_lockbox');
chk(!!lp,'demo puzzle "pz_lockbox" registered');
chk(lp.steps.length===3,'demo puzzle has 3 chained steps');
chk(lp.steps.map(s=>s.id).join(',')==='clue_drawing,lockbox,cabinet','step order is the chain');
chk(lp.steps[0].kind==='inspect'&&lp.steps[1].kind==='code'&&lp.steps[2].kind==='answer','steps use different mechanics');
chk(!!lp.onComplete,'puzzle has an onComplete event hook');

/* ============ 2. world-bound nodes exist ============ */
chk(!!node('clue_drawing')&&!!node('lockbox')&&!!node('cabinet'),'all three chain nodes are placed in the world (slice_bld)');
chk(node('clue_drawing').type==='puzzle','nodes are interactables of type "puzzle"');

/* ============ 3. gating: clue first, then code, then item-locked cabinet ============ */
reset();
chk(PZ.nodeState('pz_lockbox','clue_drawing')==='active','step 1 (clue) is active at start');
chk(PZ.nodeState('pz_lockbox','lockbox')==='locked','step 2 (code) is locked before the clue is found');
chk(PZ.nodeState('pz_lockbox','cabinet')==='locked','step 3 (cabinet) is locked before the key exists');
chk(PZ.requireMet('pz_lockbox',PZ.step('pz_lockbox','cabinet')).kind==='item','cabinet is gated by an ITEM (item unlocks location C)');
chk(PZ.requireMet('pz_lockbox',PZ.step('pz_lockbox','lockbox')).kind==='step','lockbox is gated by a previous STEP');

/* ============ 4. locked node refuses & explains (in-world) ============ */
enterScene('slice_bld',SB().spawn,{silent:true});reset();
face(node('cabinet'),0,0.6);
chk(INTERACT.prompt(curInt).indexOf('تحتاج')>=0,'locked node prompt says what it needs ("'+INTERACT.prompt(curInt)+'")');
doInteract();
chk(PZUI.open===false,'interacting with a locked node does not open the puzzle');
face(node('lockbox'),0,0.6);
chk(INTERACT.prompt(curInt).indexOf('ليس بعد')>=0,'step-locked node prompt says "not yet"');

/* ============ 5. STEP 1 — find clue A (inspect) via world interaction ============ */
face(node('clue_drawing'),0,0.6);
chk(curInt&&curInt.step==='clue_drawing','clue node is focusable');
doInteract();
chk(PZUI.open===true&&PZUI.sid==='clue_drawing','interacting opens the puzzle panel at the clue step');
chk(byText('تحقّق'),'panel renders a check action');
PZ.submit();
chk(PZUI.solved===true,'inspect step solves on submit');
chk(byClass('pzClue'),'solved step reveals its clue text');
chk(!!byText('تابع'),'a continue button follows the clue');
PZ.advance();
chk(PZ.stepSolved('pz_lockbox','clue_drawing'),'clue step recorded as solved');
chk(G.flags.pz_drawing===true,'clue reward flag applied');
chk((G.objective||'').indexOf('الصندوق')>=0,'clue reward set the next objective (points to location B)');
chk(PZUI.open===false,'panel closed after advancing');

/* ============ 6. STEP 2 — puzzle B (code) : wrong then right ============ */
chk(PZ.nodeState('pz_lockbox','lockbox')==='active','code step unlocked after the clue');
PZ.open('pz_lockbox','lockbox');
chk(!!byClass('pzPad'),'code step renders a keypad');
chk(!!byClass('pzCode'),'code step renders digit slots');
/* click keypad: 0 0 0 -> wrong */
function press(d){const pad=byClass('pzPad');pad.children.slice().find(x=>x.innerHTML===d).onclick();}
press('0');press('0');press('0');
chk(PZUI.input.join('')==='000','keypad clicks build the entered code');
PZ.submit();
chk(PZUI.solved===false,'wrong code does not solve');
chk(!!byClass('pzMsg'),'wrong code shows a failure message');
chk(!PZ.stepSolved('pz_lockbox','lockbox'),'wrong code did not mark the step solved');
/* now the right code 314 */
PZ.open('pz_lockbox','lockbox');
press('3');press('1');press('4');
PZ.submit();
chk(PZUI.solved===true,'correct code solves the step');
PZ.advance();
chk(PZ.stepSolved('pz_lockbox','lockbox'),'code step recorded solved');
chk(INV.has('lockbox_key'),'solving puzzle B gave the KEY item (reward)');
chk((G.objective||'').indexOf('المطبخ')>=0,'reward pointed to location C (kitchen)');

/* ============ 7. STEP 3 — location C unlocked by the item, answer mechanic, final event ============ */
chk(PZ.nodeState('pz_lockbox','cabinet')==='active','cabinet unlocked once the key is held');
const echoBefore=G.echo,anomBefore=G.stats.anomalies;
PZ.open('pz_lockbox','cabinet');
chk(!!byClass('pzOpts'),'answer step renders options');
/* wrong option */
byClass('pzOpts').children.slice().find(x=>x.innerHTML.indexOf('هلال')>=0).onclick();
chk(PZUI.sel==='moon','clicking an option selects it');
PZ.submit();
chk(PZUI.solved===false,'wrong answer does not solve');
/* right option */
PZ.open('pz_lockbox','cabinet');
byClass('pzOpts').children.slice().find(x=>x.innerHTML.indexOf('شمس')>=0).onclick();
PZ.submit();
chk(PZUI.solved===true,'correct answer solves the final step');
PZ.advance();
chk(PZ.solved('pz_lockbox')===true,'whole puzzle chain is solved');
chk(G.flags.pz_cabinet===true,'final step reward flag applied');
chk(G.echo>=0.45,'onComplete fired a world event (echo bumped)');
chk((G.objective||'').indexOf('الشارع')>=0,'final clue leads back to an earlier location (the street)');

/* ============ 8. solved nodes report "done" in-world ============ */
face(node('clue_drawing'),0,0.6);
chk(INTERACT.prompt(curInt).indexOf('تمّ')>=0,'a solved node prompt shows "done"');
doInteract();
chk(PZUI.open===false,'a solved node does not re-open the puzzle');

/* ============ 9. MODULARITY — add a brand-new puzzle (new mechanic) with zero engine edits ============ */
reset();
defPuzzle({id:'pz_test',name:'لغز اختبار',steps:[
  {id:'seq',kind:'sequence',solution:['a','b'],question:'رتّب الرمزين',clue:'تمّ الترتيب',
   options:[{id:'a',label:'أول'},{id:'b',label:'ثان'},{id:'c',label:'ثالث'}],
   reward:{flag:'pzTestDone',item:'batteries'}}
]});
chk(!!PZ.def('pz_test'),'a newly registered puzzle exists');
PZ.node({puzzle:'pz_test',step:'seq'});
chk(PZUI.open&&PZUI.id==='pz_test','new puzzle opens through the same node() entry point');
chk(!!byClass('pzSeq')||!!byClass('pzOpts'),'sequence step renders its picker');
const opts=byClass('pzOpts');
opts.children.slice().find(x=>x.innerHTML==='أول').onclick();
byClass('pzOpts').children.slice().find(x=>x.innerHTML==='ثان').onclick();
chk(PZUI.input.join(',')==='a,b','sequence input recorded in order');
PZ.submit();
chk(PZUI.solved===true,'custom sequence puzzle solved');
PZ.advance();
chk(G.flags.pzTestDone===true&&INV.has('batteries'),'custom puzzle reward applied (flag + item)');
chk(PZ.solved('pz_test'),'custom puzzle fully solved');

/* ============ 10. SAVE / LOAD persists puzzle progress ============ */
reset();
enterScene('slice_bld',SB().spawn,{silent:true});
PZ.node(node('clue_drawing'));PZ.submit();PZ.advance();      // solve step 1
chk(PZ.stepSolved('pz_lockbox','clue_drawing'),'step solved before saving');
saveGame(true);
const raw=localStorage.getItem(SAVEKEY);
chk(raw&&raw.indexOf('clue_drawing')>=0,'save data contains puzzle progress');
G.pz={};                                                       // wipe live progress
loadGame();
chk(PZ.stepSolved('pz_lockbox','clue_drawing'),'puzzle progress restored from save');
chk(PZ.nodeState('pz_lockbox','lockbox')==='active','restored progress re-unlocks the next step');

console.log(fails?('\n'+fails+' FAILURES'):'\nPUZZLE FRAMEWORK SUITE OK');
