/* ---- Phase 1: Player Controller foundation ---- */
let fails=0;
const ok=m=>console.log('  ok  '+m);
const bad=m=>{console.log('FAIL  '+m);fails++;};
const chk=(c,m)=>c?ok(m):bad(m);

boot();
startGame(true);
function closeAll(){DLG.open=false;DOC.open=false;CODE.open=false;NB.open=false;G.paused=false;}
function step(n){for(let i=0;i<n;i++){
  G.dt=0.016;G.time+=0.016;
  if(!G.paused&&!DLG.open&&!DOC.open&&!CODE.open&&!NB.open){
    try{updatePlayer(0.016);updateEnts(0.016);updateBeats(0.016);updateAnoms(0.016);updateHint();}
    catch(e){bad('sim: '+e.stack.split('\n').slice(0,2).join(' | '));return false;}
  }
  try{update3D(0.016);}catch(e){bad('3D: '+e.stack.split('\n').slice(0,2).join(' | '));return false;}
  if(DLG.open){try{nextLine();}catch(e){}}
}return true;}
closeAll();

/* find open ground with room to walk */
function findOpen(scene){
  const g=scene.g;
  const clear=(x,y)=>{for(let a=0;a<8;a++){const ang=a*Math.PI/4;
    for(let r=0.6;r<=3;r+=0.6)if(solidT(getT(g,Math.floor(x+Math.cos(ang)*r),Math.floor(y+Math.sin(ang)*r))))return false;}return true;};
  for(let y=2;y<scene.h-2;y++)for(let x=2;x<scene.w-2;x++)if(clear(x+0.5,y+0.5))return{x:x+0.5,y:y+0.5};
  return null;
}

/* ============ 1. vertical physics fields exist ============ */
const P0=G.player;
chk(P0.py===0&&P0.vy===0&&P0.grounded===true,'player spawns grounded with py/vy/grounded');
chk(typeof P0.modelYaw==='number','player has modelYaw (body facing)');
chk(P0.anim==='idle','player starts in idle animation state');
chk(typeof groundHeight==='function','groundHeight() hook exists');

/* ============ 2. gravity keeps the player on the floor ============ */
step(60);
chk(Math.abs(G.player.py)<1e-6,'after 60 frames py stays at ground level ('+G.player.py.toFixed(6)+')');
chk(G.player.grounded===true,'player remains grounded on flat floor');
chk(Math.abs(G.player.vy)<1e-6,'vertical velocity is zeroed on ground ('+G.player.vy.toFixed(6)+')');

/* ============ 3. gravity pulls a lifted player back down ============ */
G.player.py=3.0;G.player.vy=0;G.player.grounded=false;
let fell=false;
for(let i=0;i<120;i++){G.dt=0.016;G.time+=0.016;updatePlayer(0.016);
  if(G.player.py<3.0)fell=true;}
chk(fell,'gravity pulls an airborne player downward');
chk(Math.abs(G.player.py)<1e-6&&G.player.grounded===true,'airborne player lands back on the floor (py='+G.player.py.toFixed(4)+')');

/* ============ 4. four-direction movement (camera-relative) ============ */
enterScene('outdoor',{x:25.5,y:38.5},{silent:true});closeAll();step(10);
const open=findOpen(G.scene);
chk(!!open,'found open ground in outdoor scene');
function probe(aim,keys,frames){
  const P=G.player;
  IN.aim=aim;IN.lookX=IN.lookY=0;IN.movedByMouse=true;
  P.x=open.x;P.y=open.y;P.py=0;P.vy=0;P.hidden=false;P.sta=100;P.injured=0;P.crouchLock=false;
  IN.aim=aim;
  const sx=P.x,sy=P.y;
  IN.keys={};keys.forEach(k=>IN.keys[k]=true);
  for(let i=0;i<frames;i++)updatePlayer(0.05);
  IN.keys={};
  return{dx:P.x-sx,dy:P.y-sy};
}
const e=probe(0,['KeyW'],30);
chk(e.dx>1&&Math.abs(e.dy)<0.3,'W facing east -> walks east (dx='+e.dx.toFixed(2)+')');
const n=probe(-Math.PI/2,['KeyW'],30);
chk(n.dy<-1&&Math.abs(n.dx)<0.3,'W facing north -> walks north (dy='+n.dy.toFixed(2)+')');
const w=probe(Math.PI,['KeyW'],30);
chk(w.dx<-1&&Math.abs(w.dy)<0.3,'W facing west -> walks west');
const so=probe(Math.PI/2,['KeyW'],30);
chk(so.dy>1&&Math.abs(so.dx)<0.3,'W facing south -> walks south');
const st=probe(0,['KeyD'],30);
chk(st.dy>1&&Math.abs(st.dx)<0.3,'D facing east -> strafes south (screen-right)');

/* ============ 5. body yaw faces movement direction ============ */
IN.aim=0;IN.movedByMouse=true;G.player.modelYaw=0;
IN.keys={KeyW:true};
for(let i=0;i<40;i++)updatePlayer(0.016);
IN.keys={};
chk(Math.abs(((G.player.modelYaw-0+Math.PI*3)%TAU)-Math.PI)<0.35,
  'body yaw turns toward movement (east) while walking ('+G.player.modelYaw.toFixed(2)+')');
IN.aim=0;G.player.modelYaw=0;IN.keys={KeyD:true};
for(let i=0;i<40;i++)updatePlayer(0.016);
IN.keys={};
const dyaw=((G.player.modelYaw-Math.PI/2+Math.PI*3)%TAU)-Math.PI;
chk(Math.abs(dyaw)<0.4,'body yaw faces south when strafing right ('+G.player.modelYaw.toFixed(2)+')');

/* ============ 6. idle: body returns to camera-forward ============ */
IN.aim=1.2;G.player.modelYaw=0;IN.keys={};
for(let i=0;i<120;i++)updatePlayer(0.016);
chk(Math.abs(((G.player.modelYaw-1.2+Math.PI*3)%TAU)-Math.PI)<0.25,
  'idle body yaw eases back to camera forward ('+G.player.modelYaw.toFixed(2)+' vs aim 1.2)');

/* ============ 7. animation states ============ */
IN.keys={};updatePlayer(0.016);
chk(G.player.anim==='idle','anim=idle when standing still');
IN.keys={KeyW:true};updatePlayer(0.016);
chk(G.player.anim==='walk','anim=walk when moving');
IN.keys={KeyW:true,ShiftLeft:true};G.player.sta=100;updatePlayer(0.016);
chk(G.player.anim==='sprint','anim=sprint when Shift+move');
IN.keys={KeyW:true,KeyC:true};updatePlayer(0.016);
chk(G.player.anim==='crouch','anim=crouch when C+move');
IN.keys={};

/* ============ 8. camera smoothly follows (damping, not rigid) ============ */
enterScene('outdoor',{x:25.5,y:38.5},{silent:true});closeAll();
E3.view='ots';E3.camSnap=true;step(2);          // snap onto the player first
const cam0={x:E3.camera.position.x,y:E3.camera.position.y,z:E3.camera.position.z};
G.player.x+=4;G.player.y+=4;                     // teleport the player away
step(1);                                          // one frame of damping
const cam1={x:E3.camera.position.x,y:E3.camera.position.y,z:E3.camera.position.z};
const movedOneFrame=Math.hypot(cam1.x-cam0.x,cam1.z-cam0.z);
const playerGap=Math.hypot(4,4);
chk(movedOneFrame>0.001&&movedOneFrame<playerGap,
  'camera eases toward the player instead of snapping (moved '+movedOneFrame.toFixed(3)+' of '+playerGap.toFixed(2)+' in 1 frame)');
step(90);
const camFar=Math.hypot(E3.camera.position.x-G.player.x,E3.camera.position.z-G.player.y);
chk(camFar>1.2&&camFar<4.5,'camera settles at a third-person distance behind the player ('+camFar.toFixed(2)+')');

/* ============ 9. camera never ends up inside a wall ============ */
enterScene('apartment',SCENES.apartment.spawn,{silent:true});closeAll();
let inside=0;
for(let i=0;i<240;i++){IN.aim=i*0.27;step(1);
  const c=E3.camera.position;if(solidAt3(c.x,c.z,c.y))inside++;}
chk(inside===0,'smooth camera never penetrates a wall ('+inside+'/240)');

/* ============ 10. collision: player cannot walk through walls ============ */
enterScene('apartment',SCENES.apartment.spawn,{silent:true});closeAll();
const ap=G.scene;
let bx=-1,by=-1;
for(let y=2;y<ap.h-2&&bx<0;y++)for(let x=2;x<ap.w-2;x++){
  if(!solidT(getT(ap.g,x,y))&&solidT(getT(ap.g,x+1,y))){bx=x+0.5;by=y+0.5;break;}}
chk(bx>0,'found a floor tile with a wall to its east');
G.player.x=bx;G.player.y=by;G.player.py=0;IN.aim=0;IN.movedByMouse=true;
IN.keys={KeyW:true};
for(let i=0;i<60;i++)updatePlayer(0.05);
IN.keys={};
chk(G.player.x<bx+0.99,'wall blocks eastward movement (x '+bx.toFixed(2)+' -> '+G.player.x.toFixed(2)+')');
chk(!solidAt3(G.player.x,G.player.y,0.5),'player never ends up inside the wall tile');

/* ============ 11. camera snaps on scene entry (no swoop) ============ */
E3.camSnap=true;
enterScene('school',SCENES.school.spawn,{silent:true});closeAll();
step(1);
chk(E3.camSnap===false,'camSnap consumed on the first frame after entering a scene');
const cd=Math.hypot(E3.camera.position.x-G.player.x,E3.camera.position.z-G.player.y);
chk(cd>1.0&&cd<4.5,'camera is already correctly placed behind the player on entry ('+cd.toFixed(2)+')');

/* ============ 12. view toggle keeps working ============ */
resetCam();chk(E3.view==='ots','camera is always third-person (no first-person)');step(10);
chk(E3.playerRig.visible===true,'body visible over the shoulder');
chk(typeof E3.camDist==='number'&&E3.camDist>=CFG.camDistMin,'adjustable camera distance exists ('+E3.camDist.toFixed(2)+')');

console.log(fails?('\n'+fails+' FAILURES'):'\nPLAYER CONTROLLER SUITE OK');
