// t_vis.js — Phase 12b NIGHT VISIBILITY CALIBRATION.
// The user saw "everything black": screenshot analysis showed the scene
// renders but 91% of pixels sit at luminance 4-64/255. These checks pin the
// readability floor: moonlight, night ambient, fog tone, ground-aimed
// flashlight, boosted crash-site fires.
(function(){
  const fails=[];
  function chk(c,m){ if(!c) fails.push(m); }

  try{ boot(); }catch(e){ fails.push('boot() threw: '+e.message); }
  startGame(true);                            // fresh game -> outdoor crash site
  update3D(0.016);update3D(0.016);            // build the world once (atmo applies in build3D)

  // ============================ 1. moonlight ============================
  chk(!!E3.moon,'a moonlight directional light exists');
  chk(E3.moon&&E3.scene.children.indexOf(E3.moon)>=0,'the moon is part of the 3D scene');
  chk(E3.moon&&E3.moon.castShadow===false,'the moon casts no shadows (cheap)');
  chk(E3.moon&&E3.moon.visible===true&&E3.moon.intensity>=0.2,'the moon is ON outdoors ('+(E3.moon?E3.moon.intensity.toFixed(2):'?')+')');

  // ============================ 2. night ambient floor ============================
  chk(E3.hemi.intensity>=0.35,'outdoor hemisphere light >= 0.35 (was 0.20) — got '+E3.hemi.intensity.toFixed(2));
  chk(E3.amb.intensity>=0.09,'outdoor ambient light >= 0.09 — got '+E3.amb.intensity.toFixed(2));
  chk(E3.scene.fog.density<=0.042,'outdoor fog is not thicker than 0.042 — got '+E3.scene.fog.density.toFixed(3));
  /* NOTE: real THREE r160 stores Color.r/g/b in LINEAR space (values look
     smaller); getHex() returns the sRGB hex in both stub and real lib. */
  const fh=E3.scene.fog.color.getHex();
  const fr=(fh>>16&255)/255,fg=(fh>>8&255)/255,fb=(fh&255)/255;
  chk((fr+fg+fb)>0.15,'fog color is a readable moonlit tone, not black (#'+
    fh.toString(16).padStart(6,'0')+')');
  chk(fb>=fr,'the night tone leans blue (moonlit), not muddy');
  const bh=(E3.scene.background&&E3.scene.background.getHex)?E3.scene.background.getHex():0;
  chk(((bh>>16&255)+(bh>>8&255)+(bh&255))/255>0.15,'scene background matches the fog tone (#'+
    bh.toString(16).padStart(6,'0')+')');

  // ============================ 3. flashlight: ground aim ============================
  const P=G.player;
  P.flash=true;P.bat=CFG.batMax;P.hidden=false;
  update3D(0.016);
  const fl=E3.flash;
  chk(fl.visible===true,'the flashlight is visible when on');
  chk(fl.intensity>=13,'flashlight intensity >= 13 (was 11) — got '+fl.intensity.toFixed(1));
  chk(fl.angle>=0.54,'the cone is wide enough to walk by (angle '+fl.angle+')');
  chk(E3.flashTarget.position.y<1.2,'the flashlight aims at the GROUND ahead (target y='+
    E3.flashTarget.position.y.toFixed(2)+')');
  chk(fl.position.y>0.9&&fl.position.y<2.3,'the flashlight is mounted at head height');
  const ddx=E3.flashTarget.position.x-fl.position.x, ddz=E3.flashTarget.position.z-fl.position.z;
  chk(Math.hypot(ddx,ddz)>3,'the beam reaches a few steps ahead ('+Math.hypot(ddx,ddz).toFixed(1)+'m)');
  // off while hiding
  P.hidden=true;update3D(0.016);
  chk(fl.visible===false,'the flashlight is OFF while hiding (a dark locker)');
  P.hidden=false;
  // off when toggled off
  P.flash=false;update3D(0.016);
  chk(fl.visible===false,'the flashlight is OFF when switched off');
  P.flash=true;
  // off with a dead battery
  P.bat=0;update3D(0.016);
  chk(fl.visible===false,'the flashlight is OFF with an empty battery');
  // dying battery flickers (never exceeds full strength)
  P.bat=CFG.batMax*0.1;update3D(0.016);update3D(0.016);
  chk(fl.visible===true&&fl.intensity<=15.01,'a dying battery flickers but stays lit');
  P.bat=CFG.batMax;

  // ============================ 4. fires at the crash site ============================
  const fire=SCENES.outdoor.lights.find(l=>l.fire&&l.a>=0.4);
  chk(!!fire,'the main crash-site fire light was boosted (a>=0.4)');
  let warm=0;
  for(const pl of E3.poolLights)if(pl.visible&&pl.intensity>4){
    if(pl.color&&pl.color.r>pl.color.b)warm++;
  }
  chk(warm>=1,'at least one warm fire light is live near the spawn (got '+warm+')');

  // ============================ 5. interiors: dark but sane ============================
  enterScene('apartment',SCENES.apartment.spawn,{silent:true});
  update3D(0.016);update3D(0.016);
  chk(E3.hemi.intensity>=0.10,'indoor hemisphere floor >= 0.10 — got '+E3.hemi.intensity.toFixed(2));
  chk(E3.moon.visible===false,'no moon indoors');
  enterScene('slice_bld',SCENES.slice_bld.spawn,{silent:true});
  update3D(0.016);update3D(0.016);
  chk(Math.abs(E3.hemi.intensity-0.055)<1e-9,'explicit scene atmo still overrides defaults (slice_bld 0.055)');
  chk(E3.scene.fog.density>0.05,'interior fog stays dense (claustrophobic)');

  // ============================ report ============================
  const total=fails.length;
  if(total){ console.log('FAIL x'+total); fails.forEach(f=>console.log('  - '+f)); }
  else console.log('VISIBILITY CALIBRATION SUITE OK');
  console.log('checks_failed='+total);
  if(typeof process!=='undefined')process.exit(total?1:0);
})();
