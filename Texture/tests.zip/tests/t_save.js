// t_save.js — Phase 12 SAVE/LOAD SYSTEM: slots, autosave, full state
// round-trips (player/inventory/story/puzzle/doors/events/enemies/settings),
// quicksave/quickload, beforeunload, UI slot panel.
(function(){
  const fails=[];
  function chk(c,m){ if(!c) fails.push(m); }

  try{ boot(); }catch(e){ fails.push('boot() threw: '+e.message); }
  localStorage.clear();                       // clean slate
  chk(hasSave()===false,'hasSave() is false with an empty store');

  // ============================ 1. slot API ============================
  chk(typeof SAVE_SLOTS!=='undefined'&&SAVE_SLOTS.length===3,'SAVE_SLOTS defines 3 manual slots');
  chk(slotKey('auto')===SAVEKEY,"slotKey('auto') is the legacy SAVEKEY (back-compat)");
  chk(slotKey('2')===SAVEKEY+'_s2',"slotKey('2') is SAVEKEY+'_s2'");
  const fns={slotKey,readSlot,listSaves,newestSave,deleteSave};
for(const k in fns)chk(typeof fns[k]==='function',k+'() is a global function');
  let okDel=true; try{ deleteSave('2'); }catch(e){ okDel=false; }
  chk(okDel,'deleteSave() is safe on an empty slot');
  chk(readSlot('1')===null&&readSlot('auto')===null,'readSlot() returns null for empty slots');

  // ============================ 2. start + manual save payload ============================
  startGame(true);                            // fresh game (writes the auto slot at the end)
  chk(readSlot('auto')!==null,'startGame() autosaves into the AUTO slot');
  saveGame(false);                            // manual -> slot '1'
  const d1=readSlot('1');
  chk(d1!==null,'saveGame(false) writes manual slot 1 by default');
  chk(d1.v===2&&d1.ts>0,'the payload is v2 with a timestamp');
  chk(d1.slot==='1','the payload records its slot');
  chk('face' in d1&&'modelYaw' in d1&&'injured' in d1&&'vert' in d1&&'sta' in d1,'the payload carries full player state');
  chk(d1.set!==null&&d1.set&&typeof d1.set.sens!=='undefined','the payload embeds the settings');
  chk(d1.sceneId===G.sceneId,'the payload records the scene');

  // ============================ 3. full player state round-trip ============================
  const P=G.player;
  P.x=11.5;P.y=7.25;P.hp=1;P.rad=2.2;P.bat=0.35;P.sta=42;P.flash=false;
  P.face=2.5;P.modelYaw=1.25;P.crouchLock=true;P.injured=7;P.py=0.45;P.grounded=false;
  saveGame(false,'2');
  P.x=40;P.y=40;P.hp=3;P.rad=0;P.bat=1;P.sta=100;P.flash=true;
  P.face=0;P.modelYaw=0;P.crouchLock=false;P.injured=0;P.py=0;P.grounded=true;
  chk(loadGame('2')===true,'loadGame(slot) succeeds');
  const Q=G.player;                         // loadGame() builds a NEW player object
  chk(Math.abs(Q.x-11.5)<1e-9&&Math.abs(Q.y-7.25)<1e-9,'position restored');
  chk(Q.hp===1&&Math.abs(Q.rad-2.2)<1e-9,'hp + radiation restored');
  chk(Math.abs(Q.bat-0.35)<1e-9&&Math.abs(Q.sta-42)<1e-9,'battery + stamina restored (stamina was previously dropped)');
  chk(Q.flash===false,'flashlight state restored');
  chk(Math.abs(Q.face-2.5)<1e-9&&Math.abs(Q.modelYaw-1.25)<1e-9,'facing + body yaw restored');
  chk(Q.crouchLock===true&&Q.injured===7,'crouch lock + injury restored');
  chk(Math.abs(Q.py-0.45)<1e-9&&Q.grounded===false,'vertical offset + grounded restored');

  // ============================ 4. inventory round-trip ============================
  INV.add('medkit');INV.add('medkit');INV.add('keycard');
  saveGame(false,'3');
  const before=JSON.stringify(G.items);
  G.items={};
  loadGame('3');
  chk(JSON.stringify(G.items)===before,'inventory restored exactly ('+before+')');
  chk(G.items.medkit===2&&G.items.keycard===true,'item counts restored');

  // ============================ 5. story progress round-trip ============================
  G.story=defaultStory();STORY.start('ch1');
  G.story.obj='ch1_trace';G.story.doneObj.ch1_reach_city=true;G.story.vars.myVar=7;
  saveGame(false,'3');
  G.story=null;
  loadGame('3');
  chk(G.story&&G.story.chapter==='ch1','story chapter restored');
  chk(G.story.obj==='ch1_trace','active objective restored');
  chk(G.story.doneObj.ch1_reach_city===true&&G.story.vars.myVar===7,'completed objectives + vars restored');

  // ============================ 6. puzzle + event progress ============================
  PZ.state('sym').done.push('s1','s2');
  G.evt.done.ch1_city_echo=true;G.evt.cd.e2=12;
  saveGame(false,'3');
  G.pz={};G.evt={done:{},cd:{}};
  loadGame('3');
  chk(PZ.state('sym').done.indexOf('s2')>=0,'puzzle progress restored');
  chk(G.evt.done.ch1_city_echo===true&&G.evt.cd.e2===12,'world-event state restored');

  // ============================ 7. doors + used interactables ============================
  const door=SCENES.slice.doors.find(d=>d.id==='slice_apt_door')||SCENES.slice.doors[0];
  const int=(SCENES.slice.ints||[]).find(i=>i.id)||(SCENES.slice.ints||[])[0];
  door.open=true;door.locked=false;int.used=true;
  saveGame(false,'3');
  door.open=false;int.used=false;
  loadGame('3');
  const door2=SCENES.slice.doors.find(d=>d.id===door.id);
  const int2=(SCENES.slice.ints||[]).find(i=>i.id===int.id);
  chk(door2&&door2.open===true&&door2.locked===false,'open door stays open after load');
  chk(int2&&int2.used===true,'used interactable stays used after load');

  // ============================ 8. enemy state (position + death) ============================
  enterScene('hospital',SCENES.hospital.spawn,{silent:true});
  const ens=G.scene.entsLive.filter(e=>e.type==='creature');
  chk(ens.length>=2,'the hospital has (at least) two creatures');
  const en=ens[0];
  const ekey=en.key;
  en.x=5.5;en.y=9.5;en.dead=true;en.hp=0;
  updateEnts(0.016);                          // writer must record dead enemies too
  chk(G.flags.pos[ekey]&&G.flags.pos[ekey].dead===true,'a dead enemy is remembered as dead');
  saveGame(false,'1');
  const raw1=JSON.parse(localStorage.getItem(slotKey('1')));
  chk(raw1.flags.pos[ekey]&&raw1.flags.pos[ekey].dead===true&&raw1.flags.pos[ekey].x===5.5,'death + position serialized into the save');
  loadGame('1');
  const en2=G.scene.entsLive.find(e=>e.key===ekey);
  chk(en2&&en2.dead===true,'the enemy is still dead after load (no resurrection)');
  chk(en2&&Math.abs(en2.x-5.5)<1e-9,'the enemy position was restored from memory');
  // a live enemy's position is remembered too
  const en3=G.scene.entsLive.find(e=>e.type==='creature'&&!e.dead);
  if(en3){en3.x=12.5;en3.y=3.5;updateEnts(0.016);saveGame(false,'1');loadGame('1');
    const en4=G.scene.entsLive.find(e=>e.key===en3.key);
    chk(en4&&Math.abs(en4.x-12.5)<1,'a live enemy keeps its moved position across save/load (not reset to spawn)');}
  else chk(false,'expected a live creature in the hospital');

  // ============================ 9. multi-slot independence ============================
  for(const sl of ['auto','1','2','3'])deleteSave(sl);
  G.player.hp=3;saveGame(false,'1');
  G.player.hp=1;saveGame(false,'2');
  loadGame('1');chk(G.player.hp===3,'slot 1 keeps its own data');
  loadGame('2');chk(G.player.hp===1,'slot 2 keeps its own data');
  chk(listSaves().join(',')==='1,2','listSaves() lists the occupied manual slots');

  // ============================ 10. newest-slot resolution + delete ============================
  for(const sl of listSaves().slice())deleteSave(sl);
  deleteSave('auto');deleteSave('1');deleteSave('2');deleteSave('3');
  chk(hasSave()===false&&listSaves().length===0,'store cleared');
  G.player.hp=2;saveGame(true);               // auto, older
  const tsAuto=readSlot('auto').ts;
  G.player.hp=3;saveGame(false,'2');          // manual, newer
  loadGame();                                 // no arg -> newest
  chk(G.player.hp===3,'loadGame() with no slot loads the NEWEST save');
  deleteSave('2');
  loadGame();
  chk(G.player.hp===2,'after deleting the newest, loadGame() falls back to the auto slot');
  G.player.hp=1;saveGame(false,'3');
  loadGame();
  chk(G.player.hp===1,'a later manual save becomes the newest again');
  chk(listSaves().join(',')==='auto,3','listSaves() = auto + occupied slots');
  chk(hasSave()===true,'hasSave() sees manual slots too');

  // ============================ 11. settings travel with the save ============================
  UI.SET.sens=2.2;UI.SET.volume=0.15;
  saveGame(false,'2');
  UI.SET.sens=0.5;UI.SET.volume=0.9;UI.save();
  loadGame('2');
  chk(Math.abs(UI.SET.sens-2.2)<1e-6,'settings are restored from the loaded save (sens)');
  chk(Math.abs(UI.SET.volume-0.15)<1e-6,'settings are restored from the loaded save (volume)');

  // ============================ 12. v1 back-compat ============================
  const old=readSlot('2');
  delete old.v;delete old.ts;delete old.slot;delete old.face;delete old.modelYaw;
  delete old.crouchLock;delete old.injured;delete old.vert;delete old.grounded;delete old.set;
  old.v=1;
  localStorage.setItem(slotKey('3'),JSON.stringify(old));
  let v1ok=true;try{ v1ok=loadGame('3'); }catch(e){ v1ok=false; }
  chk(v1ok===true,'an old v1 save still loads');
  chk(G.player.face===0,'v1 defaults are safe (face=0)');

  // ============================ 13. Continue flow (boot path) ============================
  G.player.x=31.25;G.player.hp=2;
  saveGame(false,'2');
  for(const sl of ['auto','1','3'])deleteSave(sl);
  startGame(false);                           // "Continue"
  chk(G.started===true,'Continue starts the game');
  chk(Math.abs(G.player.x-31.25)<1e-9&&G.player.hp===2,'Continue restores the newest save');

  // ============================ 14. quicksave / quickload keys ============================
  for(const sl of ['auto','1','2','3'])deleteSave(sl);
  G.started=true;G.over=false;DLG.open=false;DOC.open=false;NB.open=false;INVUI.open=false;CODE.open=false;PZUI.open=false;
  UI.setOpen=false;UI.slOpen=false;
  G.player.x=33.25;
  __fireWin('keydown',{code:'F5'});
  chk(readSlot('auto')&&Math.abs(readSlot('auto').px-33.25)<1e-9,'F5 quicksaves into the AUTO slot');
  G.player.x=40;
  __fireWin('keydown',{code:'F9'});
  chk(Math.abs(G.player.x-33.25)<1e-9,'F9 quickloads the newest save');
  chk(readSlot('auto')!==null||listSaves().length>0,'quickload left the store intact');

  // ============================ 15. beforeunload autosave ============================
  chk((window._l['beforeunload']||[]).length>=1,'a beforeunload handler is registered (save on close)');
  for(const sl of ['auto','1','2','3'])deleteSave(sl);
  G.started=true;G.over=false;G.player.hp=2;
  __fireWin('beforeunload',{});
  chk(readSlot('auto')&&readSlot('auto').hp===2,'closing the game triggers one last autosave');

  // ============================ 16. UI slot panel ============================
  for(const sl of ['auto','1','2','3'])deleteSave(sl);
  saveGame(false,'2');
  UI.openSaveLoad('pause');
  chk($('slSlots').children.length===4,'the panel renders 4 rows (auto + 3 slots)');
  chk(UI._slBtns['2']&&typeof UI._slBtns['2'].load.onclick==='function','per-row Load button is wired');
  chk(UI._slBtns['auto']&&UI._slBtns['auto'].save===null,'the AUTO row has no manual Save button');
  chk(typeof UI._slBtns['1'].save.onclick==='function'&&typeof UI._slBtns['1'].del.onclick==='function','manual rows have Save + Delete');
  chk(UI.saveInfo().slot==='2','saveInfo() (no arg) describes the newest save');
  chk(UI.saveInfo('auto')===null,'saveInfo(auto) is null when the auto slot is empty');
  // save into slot 3 through the row button
  G.started=true;G.over=false;G.player.hp=1;
  UI._slBtns['3'].save.onclick();
  chk(readSlot('3')&&readSlot('3').hp===1,'row Save button writes its own slot');
  // load slot 3 through the row button
  G.player.hp=3;
  UI._slBtns['3'].load.onclick();
  chk(G.player.hp===1,'row Load button restores its slot');
  // delete through the row button
  UI._slBtns['3'].del.onclick();
  chk(readSlot('3')===null,'row Delete button empties its slot');
  // bottom buttons act on the selected slot
  UI.slSel='2';UI.doSave();
  chk(readSlot('2')&&Math.abs(readSlot('2').px-G.player.x)<1e-9,'bottom Save writes the selected slot');
  G.player.x=9.75;UI.doLoad();
  chk(Math.abs(G.player.x-readSlot('2').px)<1e-9,'bottom Load restores the selected slot');
  UI.closeSaveLoad();

  // ============================ report ============================
  const total=fails.length;
  if(total){ console.log('FAIL x'+total); fails.forEach(f=>console.log('  - '+f)); }
  else console.log('SAVE/LOAD SYSTEM SUITE OK');
  console.log('checks_failed='+total);
  if(typeof process!=='undefined')process.exit(total?1:0);
})();
