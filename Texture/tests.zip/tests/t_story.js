/* ---- Phase 10: Story System (modular Story State Machine) + Chapter 1 ---- */
let fails=0;
const ok=m=>console.log('  ok  '+m);
const bad=m=>{console.log('FAIL  '+m);fails++;};
const chk=(c,m)=>c?ok(m):bad(m);

boot();
startGame(true);

function fresh(){
  G.story=defaultStory();G.flags={};G.visits={};G.items={};G.docs=[];G.tapes=[];
  G.started=true;G.over=false;G.echo=0;G.time=100;G.sceneId='outdoor';G.scene=SCENES.outdoor;
  DLG.open=false;
}
function goto(id){G.sceneId=id;G.scene=SCENES[id];G.visits[id]=(G.visits[id]||0)+1;}

/* ============ 0. engine surface ============ */
chk(typeof STORY==='object','STORY engine present');
['start','update','onEnter','trigger','complete','activeObjective','chapter','progress','flag','has',
 'setVar','getVar','defWorld','ctx','log'].forEach(f=>chk(typeof STORY[f]==='function','STORY.'+f+'()'));
chk(typeof defChapter==='function'&&typeof defStoryEvent==='function','defChapter()/defStoryEvent() registries present');
chk(typeof CHAPTERS==='object'&&typeof STORYEVTS==='object','CHAPTERS + STORYEVTS objects present');
chk(Array.isArray(STORY.world),'STORY.world rule list present');
chk(typeof defaultStory==='function','defaultStory() factory present');

/* ============ 1. Chapter 1 is data, and complete ============ */
const ch1=CHAPTERS.ch1;
chk(!!ch1,'Chapter 1 is registered');
chk(!!ch1.title&&!!ch1.subtitle,'Chapter 1 has a title + subtitle');
chk(Array.isArray(ch1.objectives)&&ch1.objectives.length===5,'Chapter 1 has 5 ordered objectives (quest chain)');
['ch1_reach_city','ch1_shelter','ch1_trace','ch1_hospital','ch1_anomaly']
  .forEach((id,i)=>chk(ch1.objectives[i].id===id,'objective['+i+'] = '+id));
ch1.objectives.forEach(o=>chk(typeof o.when==='function'&&!!o.text,'objective "'+o.id+'" has text + a when() condition'));
chk(!!ch1.intro&&Array.isArray(ch1.intro.lines)&&ch1.intro.lines.length>0,'Chapter 1 intro carries dialogue lines');
chk(!!ch1.outro&&Array.isArray(ch1.outro.lines)&&ch1.outro.lines.length>0,'Chapter 1 outro carries dialogue lines');
chk(Array.isArray(ch1.events)&&ch1.events.length>=2,'Chapter 1 references narrative events');
chk(!!STORYEVTS.ch1_hospital_anomaly,'the hospital-anomaly story beat exists');
chk(typeof ch1.onComplete==='function','Chapter 1 has an onComplete hook');
chk(Object.keys(CHAPTERS).length===1,'only Chapter 1 is authored so far (no future chapters written)');

/* ============ 2. story state + start ============ */
fresh();
chk(G.story.chapter===null,'a fresh story has no active chapter');
chk(STORY.start('ch1')===true,'STORY.start("ch1") succeeds');
chk(G.story.chapter==='ch1','the chapter becomes active');
chk(G.story.started.ch1===true,'the chapter is marked started');
chk(G.story.obj==='ch1_reach_city','the first objective is activated');
chk(STORY.start('ch1')===false,'re-starting the same chapter is a no-op (idempotent)');
chk((G.objective||'').length>0,'the active objective reached the HUD');
chk(STORY.activeObjective()&&STORY.activeObjective().id==='ch1_reach_city','activeObjective() reports the live quest');

/* ============ 3. full quest progression through Chapter 1 ============ */
fresh();STORY.start('ch1');
G.flags.cityEntered=true;goto('slice');STORY.update(0.016);
chk(G.story.doneObj.ch1_reach_city&&G.flags.ch1_city===true,'obj1 (reach the city) completes + sets its flag');
chk(G.story.obj==='ch1_shelter','quest advances to obj2');
goto('slice_bld');STORY.update(0.016);
chk(G.story.doneObj.ch1_shelter&&G.story.obj==='ch1_trace','obj2 (enter a building) completes -> obj3');
G.items.tapeplayer=1;STORY.update(0.016);
chk(G.story.doneObj.ch1_trace&&G.flags.ch1_elena===true,'obj3 (find the trace) completes + flags the "Elena" thread');
chk(G.story.obj==='ch1_hospital','quest advances to obj4');
goto('hospital');STORY.update(0.016);
chk(G.story.doneObj.ch1_hospital&&G.flags.ch1_hospital===true,'obj4 (reach the hospital) completes');
chk(G.flags.ch1_anomalySeen===true,'the hospital-anomaly beat fired on arrival (world/event driven)');
chk(G.story.doneEvt.ch1_hospital_anomaly===true,'the beat is recorded (once)');
chk(G.story.obj==='ch1_anomaly','quest advances to obj5');
STORY.update(0.016);
chk(G.story.doneObj.ch1_anomaly&&G.story.complete.ch1===true,'obj5 completes -> Chapter 1 is complete');
chk(G.flags.ch1_complete===true,'onComplete ran (chapter-complete flag)');
chk(G.story.obj===null,'no active objective remains after the chapter ends');

/* ============ 4. order-safety: no soft-lock if conditions are met out of order ============ */
fresh();STORY.start('ch1');
goto('hospital');STORY.update(0.016);
chk(G.story.doneObj.ch1_hospital===true,'a later objective completes as soon as its condition is met');
chk(G.story.obj==='ch1_reach_city','the active quest stays on the earliest incomplete objective (no soft-lock)');

/* ============ 5. story events: scene gate + condition + once + effects ============ */
fresh();STORY.start('ch1');
G.flags.cityEntered=true;G.sceneId='outdoor';G.scene=SCENES.outdoor;
chk(STORY.trigger('ch1_city_echo')===false,'a scene-gated beat does not fire in the wrong scene');
goto('slice');
chk(STORY.trigger('ch1_city_echo')===true,'the beat fires when scene + condition match');
chk(G.story.doneEvt.ch1_city_echo===true,'the fired beat is recorded');
chk(STORY.trigger('ch1_city_echo')===false,'a once-beat will not fire twice');
chk(G.echo>=0.10,'the beat applied its effect (raised the memory echo)');

/* ============ 6. flags / vars API ============ */
fresh();
STORY.flag('t1');chk(G.flags.t1===true&&STORY.has('t1')===true,'STORY.flag()/has()');
STORY.flag('t2',false);chk(G.flags.t2===false,'STORY.flag(k,false) sets a false flag');
STORY.setVar('v',42);chk(STORY.getVar('v')===42,'STORY.setVar()/getVar()');

/* ============ 7. world-state changes with progress (and is idempotent) ============ */
fresh();STORY.start('ch1');
const sl=SCENES.slice,origBroken=sl.lights.map(l=>!!l.broken);
sl.lights[0].broken=true;
const before=sl.lights.filter(l=>l.broken).length;
G.flags.ch1_anomalySeen=true;G.sceneId='slice';G.scene=sl;
STORY.onEnter('slice');
const after=sl.lights.filter(l=>l.broken).length;
chk(after<before,'a world-state rule changed the scene based on progress (lit a dead streetlight)');
chk(G.story.vars.__w_w_ch1_wake===1,'the world rule is marked applied');
STORY.onEnter('slice');
chk(sl.lights.filter(l=>l.broken).length===after,'the world rule does not re-apply (idempotent)');
sl.lights.forEach((l,i)=>{l.broken=origBroken[i];});   /* restore the shared scene */

/* ============ 8. progress view + the story is not over-revealed ============ */
fresh();STORY.start('ch1');
let pr=STORY.progress();
chk(pr.chapter==='ch1'&&pr.title.length>0,'progress() exposes the chapter title');
chk(pr.objectives.length===5,'progress() lists the whole chain');
chk(pr.objectives[0].active&&pr.objectives[0].revealed,'the active objective is revealed');
chk(pr.objectives[4].revealed===false,'future objectives stay hidden (nothing is spoiled up-front)');
G.flags.cityEntered=true;goto('slice');STORY.update(0.016);
pr=STORY.progress();
chk(pr.objectives[0].done&&pr.objectives[1].revealed,'completing an objective reveals the next one');

/* ============ 9. save / load round-trip ============ */
fresh();STORY.start('ch1');
G.flags.cityEntered=true;goto('slice');STORY.update(0.016);
const sObj=G.story.obj,sDone=Object.keys(G.story.doneObj).sort().join(',');
saveGame(true);
const raw=localStorage.getItem(SAVEKEY);
chk(!!raw&&raw.indexOf('"story"')>=0,'saveGame serializes G.story');
G.story=null;
chk(loadGame()===true,'loadGame succeeds');
chk(G.story&&G.story.chapter==='ch1','the story chapter was restored');
chk(G.story.obj===sObj,'the active objective was restored');
chk(Object.keys(G.story.doneObj).sort().join(',')===sDone,'completed objectives were restored');

/* ============ 10. integration: auto-start, safe no-op, test-arena excluded ============ */
fresh();G.story=null;G.sceneId='outdoor';
STORY.onEnter('slice');
chk(G.story===null,'STORY.onEnter is a safe no-op before the story starts');
STORY.update(0.016);
chk(G.story&&G.story.chapter==='ch1','STORY.update auto-starts Chapter 1 in a story scene');
fresh();G.story=null;G.sceneId='ai_arena';G.scene=SCENES.ai_arena;
STORY.update(0.016);
chk(G.story===null,'the AI test arena never triggers the story');

/* ============ 11. modularity: a new chapter/beat is pure DATA ============ */
defChapter({id:'t_chX',title:'T',subtitle:'T',objectives:[
  {id:'tx1',text:'a',when:c=>!!G.flags.txGo,flag:'txDone'},
  {id:'tx2',text:'b',when:c=>!!G.flags.txGo2}],events:['tx_evt'],onComplete:()=>{G.flags.txComplete=true;}});
defStoryEvent({id:'tx_evt',once:true,scene:'outdoor',when:c=>!!G.flags.txFire,effects:{flag:{txFired:true}}});
fresh();STORY.start('t_chX');
chk(G.story.obj==='tx1','a data-defined chapter starts at its first objective');
G.flags.txGo=true;STORY.update(0.016);
chk(G.story.doneObj.tx1&&G.flags.txDone===true&&G.story.obj==='tx2','the custom chapter advances + sets flags');
G.flags.txFire=true;G.sceneId='outdoor';G.scene=SCENES.outdoor;STORY.update(0.016);
chk(G.flags.txFired===true,'a data-defined story beat fired through the same engine');
G.flags.txGo2=true;STORY.update(0.016);
chk(G.story.complete.t_chX&&G.flags.txComplete===true,'the custom chapter completes via onComplete');
delete CHAPTERS.t_chX;delete STORYEVTS.tx_evt;
chk(!CHAPTERS.t_chX&&!STORYEVTS.tx_evt,'cleanup: only Chapter 1 ships in the game');

console.log('\n'+(fails?('FAILURES: '+fails):'STORY SYSTEM SUITE OK')+'  ('+(fails?'FAILED':'all passed')+')');
if(fails)process.exit(1);
